def split_words(s):
    return s.split(' ')